# Slic3r
Bentley Ottmann Implementation
